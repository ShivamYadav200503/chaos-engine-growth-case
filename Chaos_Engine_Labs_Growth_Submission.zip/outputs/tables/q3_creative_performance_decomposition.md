# Exhibit 13: Creative Performance Decomposition & Volume-Value Trade-offs

Empirical breakdown of all creative formats across Game A paid networks:

| Network | Creative_Type | Impressions | Installs | Spend | CPM | IPM | CPI | D7_LTV | D30_LTV | D30_ROAS | Strategic_Archetype |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Net-A | display (network auto-assembles video/image/playable) | 12,463,686 | 110,635 | $121,994.53 | $9.79 | 8.88 | $1.10 | $0.79 | $1.11 | 1.0032 | Standard Core Creative |
| Net-A | search text ad | 1,193,294 | 23,770 | $16,666.80 | $13.97 | 19.92 | $0.70 | $0.89 | $1.08 | 1.5398 | Star Format (High Volume + High ROAS) |
| Net-A | search text ad (partner sites) | 296 | 0 | $0.13 | $0.42 | 0.00 | N/A | N/A | N/A | 0.0000 | Low-Volume Experimental |
| Net-A | video (video platform) | 3,510 | 189 | $56.74 | $16.17 | 53.85 | $0.30 | $0.63 | $0.93 | 3.0939 | Star Format (High Volume + High ROAS) |
| Net-B | set: contents unknown | 370,600 | 1,752 | $11,589.75 | $31.27 | 4.73 | $6.62 | $1.74 | $3.15 | 0.4760 | High-Value Niche (Premium Monitization, Lower Scale) |
| Net-B | set: interactive end-card only | 110 | 2 | $21.15 | $192.23 | 18.18 | $10.57 | $0.18 | $0.18 | 0.0172 | High-Volume Acquisition Engine (Moderate Payback) |
| Net-B | set: playable (+ possibly video) | 1,312,685 | 18,445 | $91,241.29 | $69.51 | 14.05 | $4.95 | $2.04 | $2.97 | 0.5998 | High-Volume Acquisition Engine (Moderate Payback) |
| Net-B | unknown (not reported / not descriptive) | 413 | 0 | $5.66 | $13.71 | 0.00 | N/A | N/A | N/A | 0.0000 | Low-Volume Experimental |
| Net-C | playable (+ possibly video) | 3,923 | 41 | $107.38 | $27.37 | 10.45 | $2.62 | $0.40 | $0.95 | 0.3628 | High-Volume Acquisition Engine (Moderate Payback) |
| Net-C | video + playable | 360,681 | 3,900 | $10,010.44 | $27.75 | 10.81 | $2.57 | $0.82 | $1.33 | 0.5178 | High-Volume Acquisition Engine (Moderate Payback) |
| Net-D | store image (offer-wall listing) | 0 | 4,171 | $0.00 | N/A | N/A | $0.00 | $4.51 | $6.14 | N/A | High-LTV Offerwall (Targeted IAP / Deep Engagement) |

**Strategic Creative Insights:**
1. **Net-A Search Text Ads (Star Format)**: Achieves exceptional IPM (19.92) and outstanding D30 ROAS (1.5398), delivering highly motivated intent-driven users at a low $0.70 CPI.
2. **Net-A Auto-Assemble Video/Display**: The high-volume core engine (110k installs, $1.10 CPI), achieving a sustainable 1.0032 D30 ROAS and strong ad revenue monetization.
3. **Net-B Playables vs. Net-C Video+Playable**: Net-B playables generate substantial Day-30 LTV ($2.97/user) but suffer from high CPM ($69.51) and elevated CPI ($4.95). In contrast, Net-C video+playable delivers a balanced $2.57 CPI and $1.33 D30 LTV.
4. **Net-D Offerwall Listings**: Generates unprecedented Day-30 LTV ($6.14/user) driven by deep IAP commitment and rewarded engagement, fully offsetting its high cost per action.
