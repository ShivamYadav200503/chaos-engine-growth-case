# Exhibit 11: Budget Sensitivity & CFO-vs-CEO Efficient Frontier

Constrained media spend performance across quarter budgets from $75,000 to $350,000:

| Budget | Quarter_Spend | Paid_Installs | Organic_Installs | Total_Installs | D120_Revenue_Direct | D120_ROAS_Direct | D120_Revenue_Blended | D120_ROAS_Blended | 1Y_Revenue_Direct | 1Y_ROAS_Direct | 1Y_Revenue_Blended | 1Y_ROAS_Blended | CFO_Compliant_Direct | CFO_Compliant_Blended | Net_D120_Profit_Direct |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 75000 | 75005.89 | 36764 | 1598 | 38362 | 92253.93 | 1.23 | 95532.13 | 1.2737 | 103092.33 | 1.3745 | 107006.83 | 1.4266 | True | True | 17248.04 |
| 100000 | 100000.0 | 55574 | 2415 | 57989 | 116817.71 | 1.1682 | 121773.16 | 1.2177 | 130888.47 | 1.3089 | 136805.78 | 1.3681 | True | True | 16817.71 |
| 120000 | 120000.0 | 66141 | 2875 | 69016 | 129040.4 | 1.0753 | 134938.12 | 1.1245 | 144967.1 | 1.2081 | 152009.57 | 1.2667 | True | True | 9040.4 |
| 140392 | 140392.0 | 75031 | 3261 | 78292 | 140391.16 | 1.0 | 147081.58 | 1.0476 | 158062.19 | 1.1259 | 166051.22 | 1.1828 | False | True | -0.84 |
| 160000 | 160000.0 | 82900 | 3603 | 86503 | 150600.21 | 0.9413 | 157992.29 | 0.9875 | 169755.88 | 1.061 | 178582.77 | 1.1161 | False | False | -9399.79 |
| 182325 | 182325.0 | 90615 | 3938 | 94554 | 161600.22 | 0.8863 | 169680.23 | 0.9306 | 182325.14 | 1.0 | 191973.49 | 1.0529 | False | False | -20724.78 |
| 200000 | 200000.0 | 95693 | 4159 | 99852 | 169895.45 | 0.8495 | 178428.21 | 0.8921 | 191751.84 | 0.9588 | 201940.81 | 1.0097 | False | False | -30104.55 |
| 220000 | 220000.0 | 100820 | 4382 | 105202 | 178882.5 | 0.8131 | 187872.51 | 0.854 | 201949.71 | 0.918 | 212684.67 | 0.9667 | False | False | -41117.5 |
| 250000 | 250000.0 | 107957 | 4692 | 112649 | 191656.96 | 0.7666 | 201283.28 | 0.8051 | 216427.4 | 0.8657 | 227922.19 | 0.9117 | False | False | -58343.04 |
| 300000 | 300000.0 | 117810 | 5120 | 122930 | 210777.01 | 0.7026 | 221281.93 | 0.7376 | 237884.12 | 0.7929 | 250428.05 | 0.8348 | False | False | -89222.99 |
| 350000 | 349999.99 | 122267 | 5314 | 127581 | 225082.34 | 0.6431 | 235984.69 | 0.6742 | 253465.73 | 0.7242 | 266484.22 | 0.7614 | False | False | -124917.65 |

**Key Takeaways:**
1. **CFO Breakeven Ceiling ($140,392)**: The exact maximum spend satisfying the CFO's D120 ROAS >= 1.00 mandate on direct spend is $140,392 (delivering 1.0000x D120 ROAS and 75,546 installs).
2. **Organic Halo Extension ($158,000)**: Crediting incremental organic installs (+4.85% K-factor) expands the CFO breakeven threshold to $158,000 (1.0000x blended D120 ROAS).
3. **1-Year Cash Breakeven ($182,325)**: Deploying 100% of baseline spend ($182,325) pays back 100.0% within 1 year (1.0000x 1Y ROAS) while delivering $161,600 at D120 (0.8863x).
4. **CEO Full Budget Allocation ($250,000)**: Deploying the entire $250,000 maximizes volume (107,957 installs, $191,657 D120 rev, $216,427 1Y rev), but incurs a -$58,343 D120 direct deficit (D120 ROAS = 0.7666; 0.8096 blended) due to holiday CPI inflation and network diminishing returns.
