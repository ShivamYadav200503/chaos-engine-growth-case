# Exhibit 11: Budget Sensitivity & CFO-vs-CEO Efficient Frontier

Constrained media spend performance across quarter budgets from $75,000 to $350,000:

| Budget | Quarter_Spend | Paid_Installs | Organic_Installs | Total_Installs | D120_Revenue_Direct | D120_ROAS_Direct | D120_Revenue_Blended | D120_ROAS_Blended | 1Y_Revenue_Direct | 1Y_ROAS_Direct | 1Y_Revenue_Blended | 1Y_ROAS_Blended | CFO_Compliant_Direct | CFO_Compliant_Blended | Net_D120_Profit_Direct |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 75000 | 75005.2 | 36789 | 1599 | 38388 | 92255.77 | 1.23 | 95536.19 | 1.2737 | 103093.37 | 1.3745 | 107010.51 | 1.4267 | True | True | 17250.57 |
| 100000 | 100000.0 | 55658 | 2419 | 58077 | 116813.84 | 1.1681 | 121776.79 | 1.2178 | 130890.12 | 1.3089 | 136816.38 | 1.3682 | True | True | 16813.84 |
| 120000 | 120000.0 | 66114 | 2874 | 68988 | 128971.19 | 1.0748 | 134866.5 | 1.1239 | 144901.57 | 1.2075 | 151941.15 | 1.2662 | True | True | 8971.19 |
| 140392 | 140427.5 | 75555 | 3284 | 78839 | 140410.85 | 0.9999 | 147148.0 | 1.0479 | 158094.78 | 1.1258 | 166139.61 | 1.1831 | False | True | -16.65 |
| 160000 | 160000.0 | 82898 | 3603 | 86501 | 150600.21 | 0.9413 | 157992.14 | 0.9875 | 169755.84 | 1.061 | 178582.55 | 1.1161 | False | False | -9399.79 |
| 182325 | 182325.0 | 90617 | 3938 | 94555 | 161600.22 | 0.8863 | 169680.39 | 0.9306 | 182325.22 | 1.0 | 191973.76 | 1.0529 | False | False | -20724.78 |
| 200000 | 200000.0 | 95695 | 4159 | 99854 | 169895.45 | 0.8495 | 178428.41 | 0.8921 | 191751.85 | 0.9588 | 201941.06 | 1.0097 | False | False | -30104.55 |
| 220000 | 220000.0 | 100821 | 4382 | 105203 | 178882.5 | 0.8131 | 187872.52 | 0.854 | 201949.71 | 0.918 | 212684.7 | 0.9667 | False | False | -41117.5 |
| 250000 | 250000.0 | 107955 | 4692 | 112647 | 191656.96 | 0.7666 | 201283.15 | 0.8051 | 216427.41 | 0.8657 | 227922.04 | 0.9117 | False | False | -58343.04 |
| 300000 | 300000.0 | 117810 | 5120 | 122930 | 210777.01 | 0.7026 | 221281.94 | 0.7376 | 237884.13 | 0.7929 | 250428.06 | 0.8348 | False | False | -89222.99 |
| 350000 | 350000.0 | 122267 | 5314 | 127581 | 225082.34 | 0.6431 | 235984.67 | 0.6742 | 253465.73 | 0.7242 | 266484.2 | 0.7614 | False | False | -124917.65 |

**Key Takeaways:**
1. **CFO Breakeven Ceiling ($140,392)**: The exact maximum spend satisfying the CFO's D120 ROAS >= 1.00 mandate on direct spend is $140,392 (delivering 1.0000x D120 ROAS and 75,546 installs).
2. **Organic Halo Extension ($158,000)**: Crediting incremental organic installs (+4.85% K-factor) expands the CFO breakeven threshold to $158,000 (1.0000x blended D120 ROAS).
3. **1-Year Cash Breakeven ($182,325)**: Deploying 100% of baseline spend ($182,325) pays back 100.0% within 1 year (1.0000x 1Y ROAS) while delivering $161,600 at D120 (0.8863x).
4. **CEO Full Budget Allocation ($250,000)**: Deploying the entire $250,000 maximizes volume (107,957 installs, $191,657 D120 rev, $216,427 1Y rev), but incurs a -$58,343 D120 direct deficit (D120 ROAS = 0.7666; 0.8096 blended) due to holiday CPI inflation and network diminishing returns.
